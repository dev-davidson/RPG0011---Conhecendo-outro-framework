// editora.ts
export class Editora {
  codEditora: number;
  nome: string;
}
  